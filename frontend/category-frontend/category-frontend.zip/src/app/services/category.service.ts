import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface CategoryDto {
  id?: number;
  name: string;
  createdAt?: string;
  parentId?: number;
  childrenIds?: number[];
  root?: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class CategoryService {
  private baseUrl = environment.apiUrl + '/categories';

  constructor(private http: HttpClient) {}

  getAllCategories(
    page: number,
    size: number,
    sort: string,
    filter?: { root?: boolean; dateRange?: { from?: string; to?: string } }
  ): Observable<CategoryDto[]> {
    let params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sort', sort);

    if (filter?.root !== undefined) {
      params = params.set('root', filter.root.toString());
    }
    if (filter?.dateRange) {
      if (filter.dateRange.from) params = params.set('from', filter.dateRange.from);
      if (filter.dateRange.to) params = params.set('to', filter.dateRange.to);
    }

    return this.http.get<CategoryDto[]>(this.baseUrl, { params });
  }

  createCategory(dto: CategoryDto): Observable<CategoryDto> {
    return this.http.post<CategoryDto>(this.baseUrl, dto);
  }

  updateCategory(id: number, dto: CategoryDto): Observable<CategoryDto> {
    return this.http.put<CategoryDto>(`${this.baseUrl}/${id}`, dto);
  }

  deleteCategory(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  getCategoryById(id: number): Observable<CategoryDto> {
    return this.http.get<CategoryDto>(`${this.baseUrl}/${id}`);
  }
}
