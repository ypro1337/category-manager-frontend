import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'; // Import RouterModule
import { CategoryService, CategoryDto } from '../../services/category.service';
import { MaterialModule } from '../../material.module'; // Import MaterialModule if needed
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-category-list',
  standalone: true,
  imports: [CommonModule, RouterModule, MaterialModule], // Include RouterModule
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css'],
})
export class CategoryListComponent implements OnInit {
  categories: CategoryDto[] = [];
  loading = true;
  error: string | null = null;

  constructor(
    private categoryService: CategoryService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.categoryService.getAllCategories(0, 10, 'name').subscribe({
      next: (data) => {
        this.categories = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load categories';
        console.error(err);
        this.loading = false;
      },
    });
  }



  deleteCategory(id: number) {
    this.categoryService.deleteCategory(id).subscribe({
      next: () => {
        this.categories = this.categories.filter((category) => category.id !== id);
        this.snackBar.open('Category deleted successfully!', 'Close', { duration: 3000 });
      },
      error: (err) => {
        console.error('Failed to delete category', err);
        this.snackBar.open('Failed to delete category.', 'Close', { duration: 3000 });
      },
    });
  }
}
