import { Component, Input } from '@angular/core';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CategoryService, CategoryDto } from '../../services/category.service';
import {MaterialModule} from '../../material.module';

@Component({
  selector: 'app-category-form',
  standalone: true,
  templateUrl: './category-form.component.html',
  styleUrls: ['./category-form.component.css'],
  imports: [ReactiveFormsModule, MaterialModule],
})
export class CategoryFormComponent {
  @Input() category: CategoryDto | null = null; // For edit
  form: FormGroup;
  isEditMode = false;

  constructor(
    private fb: FormBuilder,
    private categoryService: CategoryService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.form = this.fb.group({
      name: ['', Validators.required],
      parentId: [null], // Optional parent ID
    });
  }

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    if (id) {
      this.isEditMode = true;
      this.categoryService.getCategoryById(id).subscribe((data) => {
        this.category = data;
        this.form.patchValue(data);
      });
    }
  }

  onSubmit() {
    if (this.form.valid) {
      const categoryData: CategoryDto = this.form.value;

      if (this.isEditMode && this.category?.id) {
        // Edit operation
        this.categoryService
          .updateCategory(this.category.id, categoryData)
          .subscribe(() => {
            this.router.navigate(['/']);
          });
      } else {
        // Create operation
        this.categoryService.createCategory(categoryData).subscribe(() => {
          this.router.navigate(['/']);
        });
      }
    }
  }
}
