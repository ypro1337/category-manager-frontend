import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import {Router, NavigationEnd, RouterModule} from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [RouterModule],
})
export class AppComponent {
  constructor(private titleService: Title, private router: Router) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const route = this.router.routerState.snapshot.root;
        const pageTitle = route.firstChild?.data?.['title'] || 'Angular Category Management';
        this.titleService.setTitle(pageTitle);
      }
    });
  }
}
