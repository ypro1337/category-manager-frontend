import { Routes } from '@angular/router';
import { CategoryListComponent } from './components/category-list/category-list.component';
import { CategoryFormComponent } from './components/category-form/category-form.component';

export const routes: Routes = [
  { path: '', component: CategoryListComponent, data: { title: 'Category List' } },
  { path: 'create', component: CategoryFormComponent, data: { title: 'Create Category' } },
  { path: 'edit/:id', component: CategoryFormComponent, data: { title: 'Edit Category' } },
];
